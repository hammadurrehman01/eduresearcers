import React from 'react'
import TermsAndConditions from './terms-and-conditions'

function page() {
  return (
    <div>
        <TermsAndConditions/>
    </div>
  )
}

export default page