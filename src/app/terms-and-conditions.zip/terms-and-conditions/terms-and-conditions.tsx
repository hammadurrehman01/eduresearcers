import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ChevronRight, FileText } from "lucide-react"
import Link from "next/link"

export default function TermsAndConditions() {

  return (
    <div className="min-h-screen bg-background">
      <div className="relative bg-gray-900 text-primary-foreground">
        <div className="absolute inset-0 opacity-10" />
        <div className="container mx-auto relative px-4 py-16 sm:py-24 lg:py-32">
          <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
            Terms & Conditions
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-center text-primary-foreground/80">By accessing and using EduResearchers, you agree to comply with the following terms. Our platform provides academic support and research guidance for educational purposes only. Users must ensure their use of our services adheres to their institution’s policies. Unauthorized distribution, reproduction, or misuse of provided content is strictly prohibited. We do not guarantee grades or specific outcomes. Payments are final, and refunds are subject to our policy. EduResearchers reserves the right to update these terms at any time. Continued use of our services constitutes acceptance of the latest terms.</p>
        </div>
      </div>

      <div className="container px-4 py-10">
        <div className="flex flex-col gap-6 pl-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Link href="/" className="hover:underline">
              Home
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span>Terms and Conditions</span>
          </div>

          <div className="grid gap-8 lg:grid-cols-[250px_1fr] lg:gap-12">
            {/* Sticky Table of Contents */}
            <div className="hidden lg:block ">
              <div className="sticky top-6">
                <div className="flex items-center gap-2 mb-4">
                  <FileText className="h-5 w-5" />
                  <h2 className="font-semibold">On this page</h2>
                </div>
                <ScrollArea className="h-[calc(100vh-200px)]">
                  <nav className="flex flex-col gap-2">
                    <a href="#introduction" className="text-sm text-muted-foreground hover:text-foreground">
                      Introduction
                    </a>
                    <a href="#acceptance" className="text-sm text-muted-foreground hover:text-foreground">
                      Acceptance of Terms
                    </a>
                    <a href="#changes" className="text-sm text-muted-foreground hover:text-foreground">
                      Changes to Terms
                    </a>
                    <a href="#access" className="text-sm text-muted-foreground hover:text-foreground">
                      Access and Use
                    </a>
                    <a href="#content" className="text-sm text-muted-foreground hover:text-foreground">
                      User Content
                    </a>
                    <a href="#privacy" className="text-sm text-muted-foreground hover:text-foreground">
                      Privacy Policy
                    </a>
                    <a href="#termination" className="text-sm text-muted-foreground hover:text-foreground">
                      Termination
                    </a>
                    <a href="#disclaimer" className="text-sm text-muted-foreground hover:text-foreground">
                      Disclaimer
                    </a>
                    <a href="#contact" className="text-sm text-muted-foreground hover:text-foreground">
                      Contact Us
                    </a>
                  </nav>
                </ScrollArea>
              </div>
            </div>

            {/* Main Content */}
            <div className="max-w-3xl">
              <div className="prose prose-gray dark:prose-invert max-w-none">
                <section id="introduction" className="scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Introduction</h2>
                  <p className="mt-4">
                    Welcome to our platform. These Terms and Conditions govern your access to and use of our website,
                    services, and applications. By accessing or using our services, you agree to be bound by these
                    terms.
                  </p>
                </section>

                <section id="acceptance" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Acceptance of Terms</h2>
                  <p className="mt-4">
                    By accessing our services, you acknowledge that you have read, understood, and agree to be bound by
                    these Terms and Conditions. If you do not agree with any part of these terms, you must not use our
                    services.
                  </p>
                </section>

                <section id="changes" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Changes to Terms</h2>
                  <p className="mt-4">
                    We reserve the right to modify these terms at any time. We will notify users of any material changes
                    via email or through our platform. Your continued use of our services following such modifications
                    constitutes your acceptance of the updated terms.
                  </p>
                </section>

                <section id="access" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Access and Use</h2>
                  <div className="mt-4 space-y-4">
                    <p>
                      You are responsible for ensuring that your use of our services complies with all applicable laws
                      and regulations. You agree not to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Use our services for any illegal purposes</li>
                      <li>Interfere with the proper functioning of our platform</li>
                      <li>Attempt to gain unauthorized access to our systems</li>
                      <li>Transmit any harmful code or materials</li>
                    </ul>
                  </div>
                </section>

                <section id="content" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">User Content</h2>
                  <p className="mt-4">
                    By submitting content to our platform, you grant us a worldwide, non-exclusive, royalty-free license
                    to use, reproduce, modify, and distribute your content. You represent and warrant that you have all
                    necessary rights to grant this license.
                  </p>
                </section>

                <section id="privacy" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Privacy Policy</h2>
                  <p className="mt-4">
                    Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect your
                    personal information. By using our services, you consent to our privacy practices as described in
                    our Privacy Policy.
                  </p>
                </section>

                <section id="termination" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Termination</h2>
                  <p className="mt-4">
                    We reserve the right to terminate or suspend your access to our services at any time, without
                    notice, for any reason, including violation of these Terms and Conditions.
                  </p>
                </section>

                <section id="disclaimer" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Disclaimer</h2>
                  <p className="mt-4">
                    Our services are provided "as is" without any warranties, expressed or implied. We do not warrant
                    that our services will be uninterrupted, secure, or error-free.
                  </p>
                </section>

                <section id="contact" className="mt-10 scroll-mt-6">
                  <h2 className="text-2xl font-semibold tracking-tight border-b pb-2">Contact Us</h2>
                  <p className="mt-4">
                    If you have any questions about these Terms and Conditions, please contact us at:
                  </p>
                  <div className="mt-4">
                    <Button variant="outline">
                      <Link href="mailto:support@eduresearchers.com">support@eduresearchers.com</Link>
                    </Button>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

